<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
      .photo{
        height: 350px;
        width: 300px;
        border:2px solid gray;
        margin:10px;

      }
      .pack{
        border: 3px solid pink;
        padding:25px 100px;

      }
    </style>
  </head>
  <body>
    <center>
      <img class="photo"
      src="https://rukminim2.flixcart.com/image/550/650/xif0q/shirt/r/9/n/xxl-patta-14-jai-textiles-original-imagn2fzpawqukgq.jpeg?q=90&crop=false"
      alt="Your Photo">
    </center>
    <br>

    <div class="pack" style="font-weight: 400">
    <h3 style="color: burlywood">Men Slim Fit Striped Spread Collar Casual Shirt</h3>
    <p><span style="color: rgb(214, 35, 202);">pproduct-description:</span>
      A product which gives comfort and stlyle.
  </p>
  <p><span style="color: rgb(214, 35, 202);">price :</span> 30 $</p>
  <p><span style="color: rgb(214, 35, 202);">delivery status :</span> packed</p>
  <h5 style="color: red">YOUR ORDER MAY DELIVER BY TOMMOROW</h5>
</div>
  
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>